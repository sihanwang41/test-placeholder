from ray import serve
from ray.serve.drivers import DefaultgRPCDriver, gRPCIngress

@serve.deployment(ray_actor_options={"runtime_env": {"pip": ["imageio==2.21.1", "opencv-python==4.5.5.64", "yolov5==6.1.0", "sentence-transformers==2.2.2", "onnx==1.13.1", "onnxruntime==1.13.1", "boto3"]}})
class D1:
    def __call__(self, input):
        return input["a"]

entry = DefaultgRPCDriver.bind(D1.bind())
