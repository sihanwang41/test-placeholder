from fastapi import FastAPI
from ray import serve
import os

# Use this var to test service inplace update. When the env var is updated, users see new return value.
msg = os.getenv("SERVE_RESPONSE_MESSAGE", "Hello world!")

serve.start(detached=True)

app = FastAPI()

@serve.deployment(route_prefix="/", autoscaling_config={
    "min_replicas": 0,
    "max_replicas": 20,
    "upscale_delay_s": 0.1,
    "downscale_delay_s": 60
})
@serve.ingress(app)
class HelloWorld:
    @app.get("/")
    def hello(self):
        import time
        time.sleep(5)
        return msg

    @app.get("/healthcheck")
    def healthcheck(self):
        return

entrypoint = HelloWorld.bind()

# The following block will be executed if the script is run by Python directly
if __name__ == "__main__":
    serve.run(entrypoint)

