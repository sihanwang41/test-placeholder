from ray import serve

@serve.deployment
class Model:
    def __call__(self):
        return "hello"

model = Model.bind()
serve.run(model, name="app2", route_prefix="/app2")
