from ray import serve

from fastapi import FastAPI

from ray import serve


app = FastAPI()


@serve.deployment(num_replicas=1, route_prefix="/")
@serve.ingress(app)
class APIIngress:
    def __init__(self, gpu_handle) -> None:
        self.handle = gpu_handle

    @app.get("/echo")
    async def echo(self, prompt: str):
        return self.handle.remote(promt)

@serve.deployment(
    ray_actor_options={"num_gpus": 1},
    autoscaling_config={"min_replicas": 1, "max_replicas": 2},
)
class GPUModel:
    def __call__(self, num: int):
        return num

entry = APIIngress.bind(GPUModel.bind())
